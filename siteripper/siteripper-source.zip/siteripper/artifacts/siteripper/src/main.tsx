import { createRoot } from "react-dom/client";
import { ClerkProvider } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { dark } from "@clerk/themes";
import App from "./App";
import "./index.css";

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;
const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

createRoot(document.getElementById("root")!).render(
  <ClerkProvider
    publishableKey={clerkPubKey}
    proxyUrl={clerkProxyUrl}
    routerPush={(to) => window.history.pushState(null, "", to)}
    routerReplace={(to) => window.history.replaceState(null, "", to)}
    appearance={{
      baseTheme: dark,
      variables: {
        colorPrimary: "#4f83ff",
        colorBackground: "#0f0f11",
        colorInputBackground: "#1a1a1e",
        colorNeutral: "#ffffff",
      },
    }}
  >
    <App basePath={basePath} stripBase={stripBase} />
  </ClerkProvider>,
);
